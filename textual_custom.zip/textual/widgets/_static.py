from __future__ import annotations

from rich.console import RenderableType
from ..widget import Widget, Reactive


class Static(Widget):
    has_focus: Reactive[bool] = Reactive(False)
    mouse_over: Reactive[bool] = Reactive(False)
    style: Reactive[str] = Reactive("")
    def __init__(self, renderable: RenderableType, name: str | None = None) -> None:
        super().__init__(name)
        self.renderable = renderable

    def render(self) -> RenderableType:
        return self.renderable

    async def update(self, renderable: RenderableType) -> None:
        self.renderable = renderable
        self.require_repaint()

    async def on_focus(self, event: events.Focus) -> None:
        self.has_focus = True

    async def on_blur(self, event: events.Blur) -> None:
        self.has_focus = False

    async def on_enter(self, event: events.Enter) -> None:
        self.mouse_over = True

    async def on_leave(self, event: events.Leave) -> None:
        self.mouse_over = False
